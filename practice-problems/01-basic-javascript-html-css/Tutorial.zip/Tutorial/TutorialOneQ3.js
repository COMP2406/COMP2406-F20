let a="";
for(i=0;i<7; i++){
	a=a+"#"
	console.log(a);
}
