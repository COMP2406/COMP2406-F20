const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let bookSchema = Schema({
	title: String,
	authors: String,
	isbn: String,
	ratings: [Number]
});

module.exports = mongoose.model("Book", bookSchema);
